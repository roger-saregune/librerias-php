-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 21-06-2010 a las 17:58:00
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `test`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE IF NOT EXISTS `comentarios` (
  `comentario_id` int(11) NOT NULL AUTO_INCREMENT,
  `comentario_item_id` int(11) NOT NULL,
  `comentario_titulo` varchar(80) NOT NULL,
  `comentario_texto` text NOT NULL,
  `comentario_usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`comentario_id`),
  KEY `comentario_item_id` (`comentario_item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`comentario_id`, `comentario_item_id`, `comentario_titulo`, `comentario_texto`, `comentario_usuario_id`) VALUES
(1, 1, 'primer comentario al 1', '', 1),
(2, 1, 'seguno comentario al 1', '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diccio`
--

CREATE TABLE IF NOT EXISTS `diccio` (
  `diccioID` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` varchar(100) NOT NULL DEFAULT '',
  `campo` varchar(100) NOT NULL DEFAULT '',
  `orden` int(11) NOT NULL DEFAULT '0',
  `tipo` varchar(100) NOT NULL DEFAULT '',
  `longitud` int(11) NOT NULL DEFAULT '0',
  `notas` text NOT NULL,
  PRIMARY KEY (`diccioID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `diccio`
--

INSERT INTO `diccio` (`diccioID`, `tabla`, `campo`, `orden`, `tipo`, `longitud`, `notas`) VALUES
(1, 'diccio', 'diccioID', 0, 'int', 11, ''),
(2, 'diccio', 'tabla', 1, 'string', 100, ''),
(3, 'diccio', 'campo', 2, 'string', 100, ''),
(4, 'diccio', 'orden', 3, 'int', 11, ''),
(5, 'diccio', 'tipo', 4, 'string', 100, ''),
(6, 'diccio', 'longitud', 5, 'int', 11, ''),
(7, 'diccio', 'notas', 6, 'blob', 65535, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `itag`
--

CREATE TABLE IF NOT EXISTS `itag` (
  `itag_es` varchar(20) NOT NULL,
  `itag_eu` varchar(20) NOT NULL,
  PRIMARY KEY (`itag_es`),
  KEY `itag_eu` (`itag_eu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `itag`
--

INSERT INTO `itag` (`itag_es`, `itag_eu`) VALUES
('hola', 'kaixo'),
('adios', 'agur');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_nombre` varchar(80) NOT NULL,
  `item_tipo` int(11) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `item_nombre` (`item_nombre`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `item`
--

INSERT INTO `item` (`item_id`, `item_nombre`, `item_tipo`) VALUES
(1, 'primero', 2),
(2, 'segundo', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE IF NOT EXISTS `tipos` (
  `tipo_id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_literal` varchar(60) NOT NULL,
  PRIMARY KEY (`tipo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`tipo_id`, `tipo_literal`) VALUES
(1, 'Normal (1)'),
(2, 'Plus(2)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_nombre` varchar(25) NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usuario_id`, `usuario_nombre`) VALUES
(1, 'Fulano'),
(2, 'Mengano');
